import re
import datetime
from zoneinfo import ZoneInfo
import os
import logging
# Add these imports for Azure Document Intelligence
from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeDocumentRequest

logger = logging.getLogger()


def make_table_item_from_text(text, event):
    """
    This function is used to make a table item put into DynamoDB from text.

    design DynamoDB table
        userID          automatically   get from LINE Messaging API
        timestamp       automatically   get from Python library
        groupID         automatically   get from LINE Messaging API
        date            optional        get from message
        category        mandatory       get from message
        sub-category    optional        get from message
        price           mandatory       get from message
        memo            optional        get from message

        priceの前に書かれている文字列はカテゴリーとして扱う
        ただし、カテゴリーが複数行にまたがる場合は以下のパターンに従う
            1行目: category
            2行目: sub-category
            3行目: sbu-categoryよりをさらに細分化したカテゴリー

        priceは必ず整数でなければならない

        priceの後に書かれている文字列はメモとして扱う
    """
    logger.info("[make_table_item_from_text] Starting text parsing")

    # tmp return value
    item = {}
    # split message
    splitted = text.split('\n')

    '''
        userID, timestamp and groupID
    '''
    # If event isn't empty, get userID, timestamp and groupID from LINE event
    if event:
        item['userID'] = event.source.user_id
        item['timestamp'] = event.timestamp
        item['groupID'] = event.source.group_id
    # In case of being called directly from terminal, not via LINE event
    else:
        item['userID'] = '-'
        item['timestamp'] = '-'
        item['groupID'] = '-'

    '''
        date
    '''
    # for each splitted item, check if it is date.
    # if it is, treat it as date.
    is_date = [bool(re.match(r'^[0-9]{4}-[0-9]{4}(-[0-9]{4})?$', item)) for item
               in splitted]

    # if True in is_date, get the date
    if True in is_date:
        # item['date'] = splitted[is_date.index(True)]
        tmp_item_date = splitted[is_date.index(True)]

        # if time is not specified, fill it with '-1200'
        if bool(re.match(r'^[0-9]{4}-[0-9]{4}$', tmp_item_date)):
            tmp_item_date += '-1200'

        item['date'] = tmp_item_date

        splitted = splitted[1:]
    else:
        # if there is no date, use today's date like 'YYYY-MMDD-hhmm'
        # time-zone is 'Asia/Tokyo'
        # example: 2021-0123-1234
        # example: 2021-0123-2345
        item['date'] = datetime.datetime.now(
            ZoneInfo("Asia/Tokyo")
        ).strftime('%Y-%m%d-%H%M')
   
    '''
        price, category, sub-category, memo
    '''
    # for each splitted item, check if it is numeric.
    # if it is, treat it as price.
    is_price = [bool(re.match(r'^([0-9],*)+[0-9]$', item)) for item
                in splitted]

    # if True in is_price, get the price
    if True in is_price:
        # get the category
        item['category'] = splitted[0]

        # get the sub-category if it exists
        if is_price.index(True) >= 2:
            item['sub-category'] = splitted[1]
        else:
            item['sub-category'] = '-'

        price = splitted[is_price.index(True)]
        item['price'] = price

        # get the memo if it exists
        if len(splitted) > is_price.index(True) + 1:
            item['memo'] = splitted[is_price.index(True) + 1]
        else:
            item['memo'] = '-'

    else:
        item['category'] = '-'
        item['sub-category'] = '-'
        item['price'] = '0'
        item['memo'] = text
        logger.warning("[make_table_item_from_text] No price found, using default values")

    logger.info(f"[make_table_item_from_text] Parsing complete: {item}")
    return item


def make_table_item_from_image(image_data, event=None):
    """
    This function is used to make a table item put into DynamoDB from image.

    Returns:
        tuple: (item, analysis_result_dict)
            - item: dict for DynamoDB
            - analysis_result_dict: Azure Document Intelligence result as dict (or None on error)
    """
    logger.info("[make_table_item_from_image] Starting image analysis")

    item = {}
    analysis_result_dict = None

    '''
        userID, timestamp and groupID
    '''
    # If event isn't empty, get userID, timestamp and groupID from LINE event
    if event:
        item['userID'] = event.source.user_id
        item['timestamp'] = event.timestamp
        item['groupID'] = event.source.group_id
    # In case of being called directly from terminal, not via LINE event
    else:
        item['userID'] = '-'
        item['timestamp'] = '-'
        item['groupID'] = '-'

    try:
        # Set timeout for Azure client
        endpoint = os.environ["AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"]
        key = os.environ["AZURE_DOCUMENT_INTELLIGENCE_KEY"]

        client = DocumentIntelligenceClient(
            endpoint=endpoint,
            credential=AzureKeyCredential(key)
        )

        # If image_data is an object of BytesIO
        if hasattr(image_data, 'getvalue'):
            poller = client.begin_analyze_document(
                "prebuilt-receipt",
                AnalyzeDocumentRequest(bytes_source=image_data.getvalue())
            )

        # If image_data is the path to image file
        # In case of being called directly from terminal
        '''
            azure.core.exceptions.HttpResponseError: (InvalidRequest) Invalid request.
            Code: InvalidRequest
            Message: Invalid request.
            Inner error: {
                "code": "InvalidContentLength",
                "message": "The input image is too large.
                    Refer to documentation for the maximum file size."
            }

            Max document size is 4MB for Free(F0) tier.
            https://learn.microsoft.com/en-us/azure/ai-services/document-intelligence/service-limits?view=doc-intel-4.0.0
        '''
        if isinstance(image_data, str):
            # check if it exists
            if os.path.exists(image_data):
                # get file size
                tmp_file_size = os.path.getsize(image_data)
                file_size_mb = tmp_file_size / (1024*1024)

                # if file size is equal or more than 4MB, resize and send to AnalyzeDocumentRequest
                if file_size_mb >= 4:
                    # Resize image to reduce file size
                    from PIL import Image
                    import io

                    print(f"Image size ({file_size_mb:.2f}MB) exceeds 4MB limit. Resizing...")

                    with Image.open(image_data) as img:
                        # Convert to RGB if necessary
                        if img.mode in ('RGBA', 'P'):
                            img = img.convert('RGB')

                        # Calculate new dimensions (reduce to ~75% of original)
                        new_width = int(img.width * 0.75)
                        new_height = int(img.height * 0.75)

                        # Resize image
                        resized_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)

                        # Save to bytes with compression
                        img_buffer = io.BytesIO()
                        resized_img.save(img_buffer, format='JPEG', quality=85, optimize=True)
                        resized_bytes = img_buffer.getvalue()

                        print(f"Resized to {len(resized_bytes) / (1024*1024):.2f}MB")

                        poller = client.begin_analyze_document(
                            "prebuilt-receipt",
                            AnalyzeDocumentRequest(bytes_source=resized_bytes)
                        )

                # if file size is within the limit, send it to AnalyzeDocumentRequest directory
                else:
                    poller = client.begin_analyze_document(
                        "prebuilt-receipt",
                        AnalyzeDocumentRequest(
                            bytes_source=open(image_data, 'rb').read())
                    )

            else:
                # If image_data is not a valid file path
                raise ValueError("Invalid image file path")

        # Wait with timeout
        logger.info("[make_table_item_from_image] Waiting for Azure analysis result")
        result = poller.result(timeout=45)  # 45 seconds max
        logger.info("[make_table_item_from_image] Azure analysis complete")

        # Convert result to dict for JSON serialization (conversion failure shouldn't break main parsing)
        try:
            analysis_result_dict = convert_analysis_result_to_dict(result)
            logger.info("[make_table_item_from_image] Converted analysis result to dict")
        except Exception as e:
            logger.error(f"[make_table_item_from_image] convert_analysis_result_to_dict failed: {e}")
            analysis_result_dict = None
        # Process result and return item
        # For almost all cases, there is only one receipt in the response.
        for receipt in result.documents:
            # merchant name
            merchant_name = receipt.fields.get("MerchantName")
            if merchant_name:
                item['merchant_name'] = merchant_name.value_string

            '''
                Date
            '''
            item = get_date(item, receipt)

            '''
                category, sub-category and memo
            '''
            item = get_category(item, receipt)
 
            '''
                price
            '''
            item = get_price(item, receipt)

            # Note: Removed evidence field to avoid DynamoDB float/complex object issues
            # item['evidence'] = receipt  # This causes "Float types not supported" error

    except Exception as e:
        logger.error(f"[make_table_item_from_image] Analysis failed: {str(e)}")
        item['date'] = datetime.datetime.now(
                ZoneInfo("Asia/Tokyo")
            ).strftime('%Y-%m%d-%H%M')

        item['category'] = 'Error'
        item['price'] = 0
        item['memo'] = f'Image analysis failed: {str(e)}'

    logger.info(f"[make_table_item_from_image] Image processing complete")
    return item, analysis_result_dict


def convert_transaction_datetime_to_string(transaction_date, transaction_time):
    """
    "TransactionDate": {
        "type": "date",
        "valueDate": "2025-07-29",
        "content": "2025/07/29(",

        ...

        "confidence": 0.989,
        "spans": [
            {
                "offset": 101,
                "length": 11
            }
        ]
    },
    "TransactionTime": {
        "type": "time",
        "valueTime": "07:58:00",
        "content": "07:58",

        ...

        "confidence": 0.99,
        "spans": [
            {
                "offset": 115,
                "length": 5
            }
        ]
    }
    """
    # Convert date and time to string in the format 'YYYY-MMDD-HHMM'
    # Check if both date and time are not None
    if transaction_date is None or transaction_time is None:
        # Fall back to current time if either is None
        import datetime
        from zoneinfo import ZoneInfo
        return datetime.datetime.now(ZoneInfo("Asia/Tokyo")).strftime('%Y-%m%d-%H%M')

    date_str = transaction_date.strftime('%Y-%m%d')
    time_str = transaction_time.strftime('%H%M')
    return f"{date_str}-{time_str}"


def makeResponseMessage(item):
    """
    This function is used to make a response for LINE bot from table item
    """

    keys = ['date', 'category', 'sub-category', 'price', 'memo']
    tmp_response = [f"{key}:{item[key]}" for key in keys if key in item]
    tmp_response = '\n'.join(tmp_response)
    response = "KakeiBot is updated!\n" \
        + tmp_response

    return response


def get_category(item, receipt):

    # Receipt Type
    tmp_receipt_type = receipt.fields.get("ReceiptType")
    receipt_type = tmp_receipt_type.value_string

    if receipt_type:
        item['receipt_type'] = receipt_type

        # 食費->自炊
        if 'ヨークベニマル' in item['merchant_name']:
            item['category'] = "食費"
            item['sub-category'] = "自炊"
            item['memo'] = "ヨークベニマル"
        elif 'イトーヨーカドー' in item['merchant_name']:
            item['category'] = "食費"
            item['sub-category'] = "自炊"
            item['memo'] = "イトーヨーカドー"
        elif 'かましい' in item['merchant_name'] or 'かましん' in item['merchant_name']:
            item['category'] = "食費"
            item['sub-category'] = "自炊"
            item['memo'] = "かましん"
        elif 'OTANI' in item['merchant_name']:
            item['category'] = "食費"
            item['sub-category'] = "自炊"
            item['memo'] = "オータニ"
        elif '生鮮食品TOP' in item['merchant_name']:
            item['category'] = "食費"
            item['sub-category'] = "自炊"
            item['memo'] = "生鮮食品TOP"
        elif 'たいらや' in item['merchant_name'] or 'だいらや' in item['merchant_name']:
            item['category'] = "食費"
            item['sub-category'] = "自炊"
            item['memo'] = "たいらや"
        # 食費->外食
        elif 'LAWSON' in item['merchant_name']:
            item['category'] = "食費"
            item['sub-category'] = "外食"
            item['memo'] = "LAWSON"
        elif 'セブンイレブン' in item['merchant_name'] or 'セブン-イレブン' in item['merchant_name']:
            item['category'] = "食費"
            item['sub-category'] = "外食"
            item['memo'] = "セブンイレブン"
        elif 'FamilyMart' in item['merchant_name']:
            item['category'] = "食費"
            item['sub-category'] = "外食"
            item['memo'] = "FamilyMart"
        elif 'タリーズコーヒー' in item['merchant_name']:
            item['category'] = "食費"
            item['sub-category'] = "外食"
            item['memo'] = "タリーズコーヒー"
        elif 'STARBUCKS' in item['merchant_name']:
            item['category'] = "食費"
            item['sub-category'] = "外食"
            item['memo'] = "STARBUCKS"    
        # 食費->嗜好品
        elif 'やまや' in item['merchant_name']:
            item['category'] = "食費"
            item['sub-category'] = "嗜好品"
            item['memo'] = "やまや"
        # 日用品
        elif 'カワチ' in item['merchant_name']:
            item['category'] = "日用品"
            item['sub-category'] = "-"
            item['memo'] = "カワチ"
        elif 'マツモトキヨシ' in item['merchant_name']:
            item['category'] = "日用品"
            item['sub-category'] = "-"
            item['memo'] = "マツモトキヨシ"
        # Others
        else:
            item['category'] = "-"
            item['sub-category'] = "-"
            item['memo'] = "-"
            logger.warning(f"[get_category] No matching category for merchant: {item.get('merchant_name')}")

        return item


def get_price(item, receipt):
    """
        "Total": {
            "type": "currency",
            "valueCurrency": {
                "currencySymbol": "¥",
                "amount": 420,
                "currencyCode": "JPY"
            },
            "content": "¥420",
        }
    """
    price = receipt.fields.get("Total")
    if price and price.value_currency.amount is not None:
        # price must be integer
        item['price'] = int(price.value_currency.amount)
    else:
        item['price'] = 0

    return item


def get_date(item, receipt):
    # Transaction Date
    transaction_date = receipt.fields.get("TransactionDate")
    # Transaction Time
    transaction_time = receipt.fields.get("TransactionTime")

    # If both date and time exist, combine them.
    if transaction_date and transaction_time:
        # Combine date and time
        item['date'] = convert_transaction_datetime_to_string(
            transaction_date.value_date,
            transaction_time.value_time
        )
    else:
        # If no transaction date found, use current date in Tokyo timezone
        item['date'] = datetime.datetime.now(
            ZoneInfo("Asia/Tokyo")
        ).strftime('%Y-%m%d-%H%M')

    return item


def print_item(item):
    """
    This function is used to print item
    """
    print("item:")
    for key, value in item.items():
        print(f"{key}: {value}")
    print("\n")


def resize_image(image_bytes):
    """
    Resize image if it exceeds 4MB to reduce file size.
    Returns resized image bytes in JPEG format.

    Args:
        image_bytes: Original image data as bytes

    Returns:
        Resized image bytes (or original if under 4MB)
    """
    from PIL import Image
    import io

    image_size_mb = len(image_bytes) / (1024 * 1024)

    if image_size_mb < 4:
        return image_bytes

    print(f"Image size ({image_size_mb:.2f}MB) exceeds 4MB limit. Resizing...")

    with Image.open(io.BytesIO(image_bytes)) as img:
        # Convert to RGB if necessary
        if img.mode in ('RGBA', 'P'):
            img = img.convert('RGB')

        # Calculate new dimensions (reduce to ~75% of original)
        new_width = int(img.width * 0.75)
        new_height = int(img.height * 0.75)

        # Resize image
        resized_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)

        # Save to bytes with compression
        img_buffer = io.BytesIO()
        resized_img.save(img_buffer, format='JPEG', quality=85, optimize=True)
        resized_bytes = img_buffer.getvalue()

        print(f"Resized to {len(resized_bytes) / (1024*1024):.2f}MB")

        return resized_bytes


def generate_s3_key(user_id, timestamp, message_id):
    """
    Generate S3 object key for receipt image.
    Format: receipts/{year}/{month}/{user_id_short}_{timestamp}_{message_id}.jpg

    Args:
        user_id: LINE user ID
        timestamp: Unix timestamp in milliseconds
        message_id: LINE message ID

    Returns:
        S3 object key string
    """
    from datetime import datetime
    from zoneinfo import ZoneInfo

    # Convert timestamp to datetime in Asia/Tokyo timezone
    dt = datetime.fromtimestamp(timestamp / 1000, tz=ZoneInfo("Asia/Tokyo"))
    year = dt.strftime('%Y')
    month = dt.strftime('%m')

    # Shorten user_id (first 5 + last 5 characters)
    if len(user_id) > 10:
        user_id_short = user_id[:5] + user_id[-5:]
    else:
        user_id_short = user_id

    # Generate S3 key
    s3_key = f"receipts/{year}/{month}/{user_id_short}_{timestamp}_{message_id}.jpg"

    return s3_key


def upload_image_to_s3(image_data, s3_key, bucket_name, s3_client):
    """
    Upload image to S3 bucket.

    Args:
        image_data: Image data as bytes or BytesIO
        s3_key: S3 object key
        bucket_name: S3 bucket name
        s3_client: boto3 S3 client

    Returns:
        True if upload successful, raises exception otherwise
    """
    # Convert BytesIO to bytes if necessary
    if hasattr(image_data, 'getvalue'):
        image_bytes = image_data.getvalue()
    else:
        image_bytes = image_data

    # Upload to S3
    s3_client.put_object(
        Bucket=bucket_name,
        Key=s3_key,
        Body=image_bytes,
        ContentType='image/jpeg'
    )

    return True


def convert_analysis_result_to_dict(result):
    """
    Convert Azure Document Intelligence AnalyzeResult to a JSON-serializable dict.

    Uses SDK-provided serialization methods when available to ensure all fields
    are preserved. Falls back to manual extraction if SDK methods are not available.

    Args:
        result: AnalyzeResult object from Azure Document Intelligence

    Returns:
        dict: JSON-serializable dictionary containing the analysis result
    """
    if hasattr(result, 'as_dict'):
        return result.as_dict()

    if hasattr(result, 'model_dump'):
        return result.model_dump(mode='json')

    result_dict = {
        'api_version': result.api_version if hasattr(result, 'api_version') else None,
        'model_id': result.model_id if hasattr(result, 'model_id') else None,
        'content': result.content if hasattr(result, 'content') else None,
        'documents': []
    }

    if result.documents:
        for doc in result.documents:
            doc_dict = {
                'doc_type': doc.doc_type if hasattr(doc, 'doc_type') else None,
                'confidence': doc.confidence if hasattr(doc, 'confidence') else None,
                'fields': {}
            }

            if doc.fields:
                for field_name, field_value in doc.fields.items():
                    doc_dict['fields'][field_name] = convert_field_to_dict(field_value)

            result_dict['documents'].append(doc_dict)

    return result_dict


def convert_field_to_dict(field):
    """
    Convert a DocumentField to a JSON-serializable dict.

    Args:
        field: DocumentField object

    Returns:
        dict: JSON-serializable dictionary containing the field data
    """
    if field is None:
        return None

    field_dict = {
        'type': field.type if hasattr(field, 'type') else None,
        'content': field.content if hasattr(field, 'content') else None,
        'confidence': field.confidence if hasattr(field, 'confidence') else None,
    }

    # Handle different value types
    if hasattr(field, 'value_string') and field.value_string is not None:
        field_dict['value_string'] = field.value_string
    if hasattr(field, 'value_number') and field.value_number is not None:
        field_dict['value_number'] = field.value_number
    if hasattr(field, 'value_integer') and field.value_integer is not None:
        field_dict['value_integer'] = field.value_integer
    if hasattr(field, 'value_date') and field.value_date is not None:
        field_dict['value_date'] = field.value_date.isoformat()
    if hasattr(field, 'value_time') and field.value_time is not None:
        field_dict['value_time'] = field.value_time.isoformat()
    if hasattr(field, 'value_currency') and field.value_currency is not None:
        field_dict['value_currency'] = {
            'currency_symbol': field.value_currency.currency_symbol if hasattr(field.value_currency, 'currency_symbol') else None,
            'amount': field.value_currency.amount if hasattr(field.value_currency, 'amount') else None,
            'currency_code': field.value_currency.currency_code if hasattr(field.value_currency, 'currency_code') else None,
        }

    # Handle array type (e.g., Items in receipt)
    if hasattr(field, 'value_array') and field.value_array is not None:
        field_dict['value_array'] = [
            convert_field_to_dict(item) for item in field.value_array
        ]

    # Handle object type (nested fields)
    if hasattr(field, 'value_object') and field.value_object is not None:
        field_dict['value_object'] = {
            key: convert_field_to_dict(val) for key, val in field.value_object.items()
        }

    return field_dict


def generate_s3_key_for_json(user_id, timestamp, message_id):
    """
    Generate S3 object key for analysis result JSON.
    Format: analysis-results/{year}/{month}/{user_id_short}_{timestamp}_{message_id}.json

    Args:
        user_id: LINE user ID
        timestamp: Unix timestamp in milliseconds
        message_id: LINE message ID

    Returns:
        S3 object key string
    """
    from datetime import datetime
    from zoneinfo import ZoneInfo

    # Convert timestamp to datetime in Asia/Tokyo timezone
    dt = datetime.fromtimestamp(timestamp / 1000, tz=ZoneInfo("Asia/Tokyo"))
    year = dt.strftime('%Y')
    month = dt.strftime('%m')

    # Shorten user_id (first 5 + last 5 characters)
    if len(user_id) > 10:
        user_id_short = user_id[:5] + user_id[-5:]
    else:
        user_id_short = user_id

    # Generate S3 key
    s3_key = f"analysis-results/{year}/{month}/{user_id_short}_{timestamp}_{message_id}.json"

    return s3_key


def upload_json_to_s3(json_data, s3_key, bucket_name, s3_client):
    """
    Upload JSON data to S3 bucket.

    Args:
        json_data: dict to be serialized as JSON
        s3_key: S3 object key
        bucket_name: S3 bucket name
        s3_client: boto3 S3 client

    Returns:
        True if upload successful, raises exception otherwise
    """
    import json

    # Serialize dict to JSON string
    json_string = json.dumps(json_data, ensure_ascii=False, indent=2)

    # Upload to S3
    s3_client.put_object(
        Bucket=bucket_name,
        Key=s3_key,
        Body=json_string.encode('utf-8'),
        ContentType='application/json'
    )

    return True
